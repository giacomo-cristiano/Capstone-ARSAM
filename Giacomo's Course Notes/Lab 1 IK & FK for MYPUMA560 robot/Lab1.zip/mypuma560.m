function myrobot = mypuma560(DH)
    myrobot = SerialLink(DH);
end